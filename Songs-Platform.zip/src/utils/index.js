export const CUSTOM_URL = "https://sepolia.etherscan.io/";
export const API_URL = "https://alzelalmedical.com/api/";
export const ADDRESS = "0x0E7DAAf96Cc212f143Ae9417B9651003E55Ae7b1";
export const INFURA_URL = "https://sepolia.infura.io/v3/2b731abb6acd4158b7642d8e38d7f512";
export const ABI = [
	{
		inputs: [
			{
				internalType: "address",
				name: "new_owner",
				type: "address",
			},
		],
		name: "transferOwnership",
		outputs: [],
		stateMutability: "nonpayable",
		type: "function",
	},
];

export const GENRES = [
	{ value: "Pop", label: "Pop" },
	{ value: "Rock", label: "Rock" },
	{ value: "Synthwave", label: "Synthwave" },
	{ value: "Classical", label: "Classical" },
	{ value: "Hip Hop", label: "Hip Hop" },
	{ value: "Lo-Fi", label: "Lo-Fi" },
	{ value: "Rap", label: "Rap" },
	{ value: "R&B", label: "R&B" },
	{ value: "Electronic", label: "Electronic" },
	{ value: "Jazz", label: "Jazz" },
	{ value: "Country", label: "Country" },
	{ value: "Indie", label: "Indie" },
	{ value: "Metal", label: "Metal" },
	{ value: "Reggae", label: "Reggae" },
	{ value: "Techno", label: "Techno" },
	{ value: "Trance", label: "Trance" },
	{ value: "Trip-Hop", label: "Trip-Hop" },
	{ value: "Vaporwave", label: "Vaporwave" },
	{ value: "World", label: "World" },
];
