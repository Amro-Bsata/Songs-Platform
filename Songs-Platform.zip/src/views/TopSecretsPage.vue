<template>
	<div class="top-secrets-page">
	  <!-- Haupttitel -->
	  <h1><LockIcon :size="30" /> Top Secrets Area</h1>
  
		<!-- Nachricht, wenn KEIN Zugriff besteht -->
		<!-- Styling wie in deinem Beispiel mit spezifischen Farben -->
		<!-- Simulierter Ladezustand für die Liste -->
	   <p v-if="isLoadingSongs" class="loading">
			<LoadingIcon class="icon" :size="40" />
		  </p>
	  <div v-else-if="!hasAccess" class="access-denied">
		<h2><BlockHelperIcon :size="30" /> Access Denied</h2>
		<p>You need a TOP-Fan NFT to access this exclusive content.</p>
		<p>Visit the <router-link to="/marketplace">Marketplace</router-link> to see if any are available!</p>
		<!-- Optional: Button, um die Prüfung erneut zu versuchen (simuliert) -->
		<!-- Diese Funktion ist im Prototype immer noch simuliert -->
		<button @click="fetchMySongs" class="retry-button">Check Access Again</button>
	  </div>
  
	  <!-- Inhalt, wenn (simulierter) Zugriff besteht: Liste und Detail (conditional) -->
	  <div v-else class="content-area">
		<!-- Linke Seite: Liste der Songs -->
		<div class="song-list">
		  <h3>Exclusive Songs</h3>
		  <!-- Simulierter Ladezustand für die Liste -->
		  <p v-if="isLoadingSongs" class="loading">
			<LoadingIcon class="icon" :size="40" />
		  </p>
		  <p v-else-if="songsList.length === 0">No exclusive songs found.</p>
		  <SongCard
			v-else
			v-for="song in songsList"
			:key="song.id"
			:song="song"
			@click="selectSong(song)"
			:class="{ selected: selectedSong && selectedSong.id === song.id }"
		  />
		</div>
  
		<!-- Rechte Seite: Song Detail & Tabs (wird nur angezeigt, wenn ein Song ausgewählt ist) -->
		<div class="song-detail-view" v-if="selectedSong">
		  <h2>Details for: {{ selectedSong.song_name }}</h2>
		  <div class="detail-summary">
			   <img :src="selectedSong.image_url || 'https://placehold.co/150?text=No+Cover'" alt="Song Cover" class="detail-cover">
			   <div class="detail-info">
				  <h3>{{ selectedSong.song_name || 'Untitled Song' }}</h3>
				  <p><strong>Genre:</strong> {{ selectedSong.styles?.[0] || 'Unknown' }}</p>
				  <p v-if="selectedSong.artist"><strong>Artist:</strong> {{ selectedSong.artist }}</p>
				  <div class="audio-player-placeholder">
					<audio ref="audioPlayer" @play="playAudio" @pause="pauseAudio" class="audio-player-hidden" controls v-if="selectedSong.audio_url">
					  <source :src="selectedSong.audio_url" type="audio/mp3" />
					  Your browser does not support the audio element.
					</audio>
					<span>Audio Player Placeholder for {{ selectedSong.song_name }}</span>
					<button @click="playAudio" v-if="!isAudioPlaying">▶ Play</button>
					<button @click="pauseAudio" v-else>⏸ Pause</button>
				  </div>
			   </div>
		  </div>
  
		  <!-- Tabbed Interface für den exklusiven Inhalt (mit Platzhaltern) -->
		  <div class="content-wrapper-tabs">
			  <div class="tabs">
				<button @click="activeTab = 'channel'" :class="{ active: activeTab === 'channel' }">
				   <BroadcastIcon :size="20" /> Channel
				</button>
				<button @click="activeTab = 'mv'" :class="{ active: activeTab === 'mv' }">
				   <VideoIcon :size="20" /> MV
				</button>
				<button @click="activeTab = 'remixes'" :class="{ active: activeTab === 'remixes' }">
				   <AlbumIcon :size="20" /> Remixes
				</button>
			  </div>
  
			  <div class="tab-content">
				<!-- Inhalt für den Channel-Tab (Platzhalter) -->
				<div v-if="activeTab === 'channel'">
				  <h2>Exclusive Channel Content</h2>
				  <p>Behind-the-scenes, special announcements, etc.</p>
				  <!-- Inhalt für Channel (Platzhalter wie in deinem Beispiel) -->
				  <p v-if="selectedSong.chat.length > 0">{{ selectedSong.chat?.[0]?.message }}</p>
				  <div v-else class="content-placeholder">Channel Area for {{ selectedSong.song_name }}</div>
				</div>
				<!-- Inhalt für den MV-Tab (Platzhalter) -->
				<div v-if="activeTab === 'mv'">
				  <h2>Official Music Video</h2>
				  <p>Watch the exclusive official music video here.</p>
				  <!-- Inhalt für MV (Video Player Platzhalter wie in deinem Beispiel) -->
				   <p v-if="selectedSong.mv">{{ selectedSong.mv }}</p>
				  <div v-else class="content-placeholder video">MV Area (Video Player Placeholder) for {{ selectedSong.song_name }}</div>
				</div>
				<!-- Inhalt für den Remixes-Tab (Platzhalter) -->
				<div v-if="activeTab === 'remixes'">
				  <h2>Exclusive Remixes</h2>
				  <p>Listen to or download special remixes.</p>
				  <!-- Inhalt für Remixes (Liste von Audio-Dateien Platzhalter wie in deinem Beispiel) -->
				  <ul v-if="selectedSong.remixs.length > 0" v-for="remix in selectedSong.remixs" :key="remix.id">
					<a :href="remix.url" target="_blank"><li>{{ remix.title }}</li></a>
				  </ul>
				  <div v-else class="content-placeholder audio-list">Remix 1, Remix 2... for {{ selectedSong.song_name }}</div>
				</div>
			  </div>
		  </div>
  
		</div>
		<!-- Placeholder, wenn kein Song ausgewählt ist -->
		<div class="song-detail-view placeholder" v-else>
		  <p>Select a song from the list to view exclusive content.</p>
		</div>
	  </div>
	</div>
  </template>

<script>
import { ref, onMounted } from "vue";
import LockIcon from "vue-material-design-icons/Lock.vue";
import BlockHelperIcon from "vue-material-design-icons/BlockHelper.vue";
import BroadcastIcon from "vue-material-design-icons/Broadcast.vue";
import VideoIcon from "vue-material-design-icons/Video.vue";
import AlbumIcon from "vue-material-design-icons/Album.vue";
import LoadingIcon from "vue-material-design-icons/Loading.vue";
import SongCard from "@/components/SongCard.vue";
import Cookies from "js-cookie";
import { ethers } from "ethers";
import axios from "axios";
import { API_URL } from "@/utils";

export default {
	name: "TopSecretsPage",
	components: {
		LockIcon,
		BlockHelperIcon,
		BroadcastIcon,
		VideoIcon,
		AlbumIcon,
		LoadingIcon,
		SongCard,
	},
	setup() {
		const hasAccess = ref(false);
		const isLoadingSongs = ref(false);
		const songsList = ref([]);
		const selectedSong = ref(null);
		const activeTab = ref("channel");
		const audioPlayer = ref(null);
		const isAudioPlaying = ref(false);
		const isLoadingSongDetails = ref(false);
		const token = ref(Cookies.get("access_token"));

		async function checkWalletConnection() {
			let walletAddress = Cookies.get("address");
			if (!walletAddress) {
				const provider = new ethers.providers.Web3Provider(window.ethereum);
				await provider.send("eth_requestAccounts", []);
				const signer = provider.getSigner();
				const address = await signer.getAddress();
				Cookies.set("address", address, { expires: 1 });
				walletAddress = address;
			}
			return walletAddress;
		}
		async function fetchMySongs() {
			const walletAddress = await checkWalletConnection();
			if (!walletAddress) return;

			isLoadingSongs.value = true;
			try {
				const response = await axios.get(`${API_URL}wallet/${walletAddress}`);

				const songsWithImages = await Promise.all(
					response.data.FAN_NFT.map(async (song) => {
						let image = null;

						try {
							if (song.uri) {
								const meta = await axios.get(song.uri);
								image = meta?.data?.response?.data?.data?.[0]?.image_url || null;
							}
						} catch (err) {
							console.warn(`Failed to fetch image for song ${song.song_name}`, err);
						}

						return {
							id: song.song_id,
							song_name: song.song_name,
							styles: song.styles || "Unknown",
							price: (song.copyright_nft_price / 1000000000).toFixed(8),
							nftId: song.song_id,
							nftContract: song.copyright_nft_contract,
							nftLink: song.uri,
							nftType: "Fan-NFT",
							owner: song.owner,
							owner_nft_contract: song.owner_nft_contract,
							url: song.uri,
							image_url: image,
						};
					}),
				);

				if (songsWithImages.length === 0) {
					hasAccess.value = false;
					return;
				}
				hasAccess.value = true;
				isLoadingSongs.value = false;
				songsList.value = songsWithImages;
			} catch (error) {
				console.error("Error fetching songs:", error);
			} finally {
				isLoadingSongs.value = false;
			}
		}
		async function fetchSongDetails(song) {
			if (!song.url) return;

			try {
				isLoadingSongDetails.value = true;
				const response = await axios.get(song.url);
				const fanArea = await axios.get(`${API_URL}get/fan/area/${song.id}`, {
					headers: {
						Authorization: `Bearer ${token.value}`,
					},
				});
				const areaData = fanArea.data;
				const apiResponse = response?.data?.response?.data?.data?.[0];
				const songData = {
					...song,
					...areaData,
					...(apiResponse || {}),
				};
				selectedSong.value = songData;
			} catch (error) {
				console.error("Error fetching song details:", error);
			} finally {
				isLoadingSongDetails.value = false;
			}
		}

		async function selectSong(song) {
			await fetchSongDetails(song);
			activeTab.value = "channel";
		}

		function playAudio() {
			audioPlayer.value.play();
			isAudioPlaying.value = true;
		}

		function pauseAudio() {
			audioPlayer.value.pause();
			isAudioPlaying.value = false;
		}

		onMounted(() => {
			fetchMySongs();
		});

		return {
			hasAccess,
			isLoadingSongs,
			songsList,
			selectedSong,
			activeTab,
			fetchMySongs,
			selectSong,
			audioPlayer,
			isAudioPlaying,
			playAudio,
			pauseAudio,
			isLoadingSongDetails,
		};
	},
};
</script>

<style scoped>
/* --- Styling basierend auf den Werten im CSS deines Originalbeispiels --- */

.top-secrets-page {
  max-width: 1200px; /* Etwas breiter für Liste+Detail */
  margin: 20px auto;
  padding: 20px; /* Padding hinzugefügt, falls in base/main.css nicht global gesetzt */
   /* Hintergrund und Textfarbe kommen wahrscheinlich aus base.css.
      Wenn du spezifische # Farben willst, müsstest du base.css überschreiben
      oder hier direkt setzen. Wir orientieren uns an deinem Beispiel-CSS: */
  background-color: var(--color-background); /* Nutzt base.css, oft dunkel */
  color: var(--color-text); /* Nutzt base.css, oft hell bei dunklem BG */
}

.top-secrets-page h1 {
  /* Styling aus base.css/App.vue kann übernommen werden */
  color: var(--color-primary); /* Akzentfarbe oder wie gewünscht */
  border-bottom: 1px solid var(--color-primary-hover); /* Trennlinie wie in base.css */
  padding-bottom: 10px;
  margin-bottom: 20px;
  display: flex; /* Für Icon */
  align-items: center; /* Für Icon */
  gap: 10px; /* Für Icon */
}

.top-secrets-page > p {
  /* Hinweis, wenn kein Zugriff */
  color: #ff6b6b; /* Rot, wie im letzten Beispiel */
  font-weight: bold;
  text-align: center;
  padding: 20px;
  border: 1px solid #444; /* Borderfarbe aus deinem Beispiel */
  background-color: #555; /* Hintergrund aus deinem Beispiel */
  border-radius: 5px;
  margin-top: 20px; /* Abstand nach oben */
}

/* Flexbox Layout für Liste und Detailansicht */
.content-area {
  display: flex;
  gap: 30px; /* Abstand zwischen Liste und Detail */
  min-height: 500px; /* Mindesthöhe, damit Bereiche nicht zu klein werden */
}

.song-detail-view h2 {
    color: var(--color-primary-hover);
}

.content-wrapper-tabs {
    /* Hintergrund wird von .song-detail-view geerbt */
    border-radius: 8px; /* Erbe den Border-Radius des Elterncontainers */
    overflow: hidden;
}

.waveform-placeholder {
  padding: 0 15px;
  font-size: 1.5em;
  color: #aaa; /* Textfarbe aus deinem Beispiel */
  padding: 10px 0;
  background-color: #f5f5f5; /* Hintergrund aus deinem Beispiel */
  border-bottom: 1px solid #eee; /* Trennlinie aus deinem Beispiel */
  flex-shrink: 0;
  color: #aaa; /* Textfarbe aus deinem Beispiel */
  background-color: #f5f5f5; /* Hintergrund aus deinem Beispiel */
  border-bottom: 1px solid #eee; /* Borderfarbe aus deinem Beispiel */
}

.tab-content h2 {
    color: #f2f2f2; /* Heller Text für Unterüberschriften */
    margin-top: 0;
    margin-bottom: 15px;
}
.tab-content p {
    margin-bottom: 15px;
}


.content-area-tab > div {
    /* Hintergrund für die Bereiche innerhalb der Tabs, wie im Beispiel */
    margin-top: 20px; /* Abstand */
    border: 1px dashed #ccc; /* Border wie im Beispiel */
    display: flex;
    justify-content: center;
    align-items: center;
    color: #aaa; /* Textfarbe wie im Beispiel */
    border-radius: 4px;
    font-style: italic;
}
.content-area-tab .channel-post {
   /* Spezialstyling für Channel Posts, falls gewünscht */
   background-color: #666; /* Etwas heller als der Tab-Content BG */
   border: none; /* Kein dashed border für Posts */
   border-left: 3px solid #42b983; /* Akzentfarbe */
   padding: 15px;
   margin-bottom: 15px;
   color: #f2f2f2;
   display: block; /* Kein Flexbox mehr */
   text-align: left;
}
.content-area-tab .channel-post h4 {
   color: #f2f2f2;
   margin-top: 0;
   margin-bottom: 5px;
}
.content-area-tab .channel-post p {
    margin-bottom: 5px;
    color: #ccc;
}
.content-area-tab .channel-post small {
    color: #aaa;
    font-style: italic;
}


.content-placeholder {
  min-height: 200px;
   /* Hintergrund und Border aus deinem Beispiel */
  background-color: #555;
  border: 1px dashed #ccc;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #aaa; /* Textfarbe aus deinem Beispiel */
  margin-top: 20px;
  border-radius: 4px;
  font-style: italic;
}

.content-placeholder.video {
   /* Hintergrund aus deinem Beispiel */
  background-color: #333;
}

.content-placeholder.audio-list {
   /* Hintergrund aus deinem Beispiel */
  background-color: #777;
}

/* Media Query für kleinere Bildschirme: Stapeln der Elemente */
@media (max-width: 768px) {
  .content-area {
    flex-direction: column; /* Liste und Detail stapeln */
    gap: 20px; /* Abstand anpassen */
  }

  .song-list {
    max-width: 100%; /* Liste nimmt volle Breite ein */
    overflow-y: visible; /* Kein Scrollen auf der Liste selbst */
    max-height: none; /* Keine feste Höhe */
  }

  .song-detail-view {
    flex: auto; /* Nimmt verfügbaren Platz ein */
  }
   .detail-summary {
       flex-direction: column; /* Bild und Info im Detail stapeln */
       align-items: center; /* Zentrieren */
       text-align: center;
   }
   .detail-summary .detail-info p {
       text-align: left; /* Text wieder linksbündig */
   }
   .tabs button {
       padding: 10px 15px; /* Weniger Padding auf kleinen Bildschirmen */
       font-size: 0.9em;
   }
    .tabs button:first-of-type {
       margin-left: 40px; /* Weniger Platz für Extra-Button auf kleinen Bildschirmen */
   }
   .tabs .extra-button {
        left: 5px; /* Näher am Rand */
   }
}

</style>
